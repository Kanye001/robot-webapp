import React, { useState } from 'react';
import { ethers } from 'ethers';

// Your deployed contract addresses
const tokenAddress = "0x0028ee6fB36e572585AA5B423dc1fbAf4F70975B";
const nftAddress = "0x7C2b4E736d32961e269F380D203541a44637e719";

// ABI for RobotCoinAdminBurn
const tokenABI = [
  {
    "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }],
    "name": "mint",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }],
    "name": "burn",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

// ABI for RobotNFT
const nftABI = [
  {
    "inputs": [{ "internalType": "address", "name": "recipient", "type": "address" }],
    "name": "mintNFT",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

function App() {
  const [account, setAccount] = useState("");
  const [amount, setAmount] = useState("");

  // Connect wallet
  async function connectWallet() {
    if (window.ethereum) {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      setAccount(accounts[0]);
      alert("Wallet connected!");
    } else {
      alert("Please install MetaMask!");
    }
  }

  // Mint Tokens
  async function mintToken() {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(tokenAddress, tokenABI, signer);
      const tx = await contract.mint(ethers.utils.parseUnits(amount, 18));
      await tx.wait();
      alert("Tokens minted!");
    } catch (err) {
      alert("Error: " + err.message);
    }
  }

  // Burn Tokens
  async function burnToken() {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(tokenAddress, tokenABI, signer);
      const tx = await contract.burn(ethers.utils.parseUnits(amount, 18));
      await tx.wait();
      alert("Tokens burned!");
    } catch (err) {
      alert("Error: " + err.message);
    }
  }

  // Mint NFT
  async function mintNFT() {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(nftAddress, nftABI, signer);
      const tx = await contract.mintNFT(account);
      await tx.wait();
      alert("NFT minted!");
    } catch (err) {
      alert("Error: " + err.message);
    }
  }

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Robot Web3 App</h1>

      <button onClick={connectWallet} style={{ marginBottom: "10px" }}>
        {account ? `Connected: ${account}` : "Connect Wallet"}
      </button>

      <h2>RobotCoinAdminBurn</h2>
      <input 
        placeholder="Amount" 
        value={amount} 
        onChange={e => setAmount(e.target.value)} 
        style={{ marginRight: "10px" }}
      />
      <button onClick={mintToken} style={{ marginRight: "5px" }}>Mint Tokens</button>
      <button onClick={burnToken}>Burn Tokens</button>

      <h2>RobotNFT</h2>
      <button onClick={mintNFT}>Mint NFT</button>
    </div>
  );
}

export default App;
